﻿
Partial Class akbar_farhangi
    Inherits System.Web.UI.Page

End Class
