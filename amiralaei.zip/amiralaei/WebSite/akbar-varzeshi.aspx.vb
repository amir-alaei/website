﻿
Partial Class akbar_varzeshi
    Inherits System.Web.UI.Page

End Class
