﻿Imports System
Imports System.Data
Partial Class admin_dastekhabarha1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("Vouroud") = "fdhgdfjjgfd" Then
                SetRepeater()
            Else
                Response.Redirect("http://localhost:8270/admin/login/Login.aspx")
            End If


        End If
    End Sub
    Private Sub SetRepeater()
        Repeater1.DataSource = SqlDataSource1
        Repeater1.DataBind()

    End Sub
End Class
