﻿
Partial Class akbar_siasi
    Inherits System.Web.UI.Page

End Class
