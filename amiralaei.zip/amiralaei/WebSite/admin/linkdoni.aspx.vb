﻿Imports System
Imports System.Data
Partial Class admin_linkdoni1
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("Vouroud") = "fdhgdfjjgfd" Then
                SetRepeater()
            Else
                Response.Redirect("http://localhost:8270/admin/login/Login.aspx")
            End If


        End If
    End Sub
    Private Sub SetRepeater()
        Repeater1.DataSource = SqlDataSource1
        Repeater1.DataBind()

    End Sub
    Protected Sub Repeater1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles Repeater1.ItemCommand
        Select Case e.CommandName
            Case "Insert"
                Dim LinkID As TextBox = TryCast(e.Item.FindControl("txtLinkID"), TextBox)
                Dim LinkURL As TextBox = TryCast(e.Item.FindControl("txtLinkURL"), TextBox)
                Dim LinkName As TextBox = TryCast(e.Item.FindControl("txtLinkName"), TextBox)


                Dim sql As String = "INSERT INTO tblLink VALUES(N'" + LinkURL.Text + "',N'" + LinkName.Text + "')"
                Dim sqlconnection As New SqlClient.SqlConnection("Data Source=.;Initial Catalog=Akhbar;Integrated Security=True")
                Dim sqlCmd As New SqlClient.SqlCommand(sql, sqlconnection)
                sqlconnection.Open()
                sqlCmd.ExecuteNonQuery()
                sqlconnection.Close()
                SetRepeater()
            Case "delete"
                Dim str As String = e.CommandArgument

                Dim sql As String = "DELETE tblLink Where LinkID='" + str + "'"
                Dim sqlconnection As New SqlClient.SqlConnection("Data Source=.;Initial Catalog=Akhbar;Integrated Security=True")
                Dim sqlCmd As New SqlClient.SqlCommand(sql, sqlconnection)
                sqlconnection.Open()
                sqlCmd.ExecuteNonQuery()
                sqlconnection.Close()
                SetRepeater()
        End Select
    End Sub
    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        SetRepeater()

    End Sub
End Class
