﻿Imports System
Imports System.Data
Partial Class admin_comment1
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("Vouroud") = "fdhgdfjjgfd" Then
                SetRepeater()
            Else
                Response.Redirect("http://localhost:8270/admin/login/Login.aspx")
            End If


        End If
    End Sub
    Private Sub SetRepeater()
        Repeater1.DataSource = SqlDataSource1
        Repeater1.DataBind()

    End Sub

    Protected Sub Repeater1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles Repeater1.ItemCommand
        Select Case e.CommandName
            Case "Insert"
                Dim CommentID As TextBox = TryCast(e.Item.FindControl("txtCommentID"), TextBox)
                Dim CommentUserName As TextBox = TryCast(e.Item.FindControl("txtCommentUserName"), TextBox)
                Dim CommentEmail As TextBox = TryCast(e.Item.FindControl("txtCommentEmail"), TextBox)
                Dim CommentData As TextBox = TryCast(e.Item.FindControl("txtCommentData"), TextBox)
                Dim CommentText As TextBox = TryCast(e.Item.FindControl("txtCommentText"), TextBox)
                Dim NewsID As TextBox = TryCast(e.Item.FindControl("txtNewsID"), TextBox)
                Dim Approved As TextBox = TryCast(e.Item.FindControl("txtApproved"), TextBox)

                Dim sql As String = "INSERT INTO tblComment VALUES(N'" + CommentID.Text + "',N'" + CommentUserName.Text + "',N'" + CommentEmail.Text + "',N'" + CommentData.Text + "',N'" + CommentText.Text + "',N'" + NewsID.Text + "',N'" + Approved.Text + "')"
                Dim sqlconnection As New SqlClient.SqlConnection("Data Source=.;Initial Catalog=Akhbar;Integrated Security=True")
                Dim sqlCmd As New SqlClient.SqlCommand(sql, sqlconnection)
                sqlconnection.Open()
                sqlCmd.ExecuteNonQuery()
                sqlconnection.Close()
                SetRepeater()
            Case "delete"
                Dim str As String = e.CommandArgument

                Dim sql As String = "DELETE tblComment Where CommentID='" + str + "'"
                Dim sqlconnection As New SqlClient.SqlConnection("Data Source=.;Initial Catalog=Akhbar;Integrated Security=True")
                Dim sqlCmd As New SqlClient.SqlCommand(sql, sqlconnection)
                sqlconnection.Open()
                sqlCmd.ExecuteNonQuery()
                sqlconnection.Close()
                SetRepeater()





            Case "Update"








        End Select
    End Sub
End Class
