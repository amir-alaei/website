﻿Imports System
Imports System.Data
Partial Class admin_login
    Inherits System.Web.UI.Page

    Protected Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Dim sql As String = "SELECT * FROM Users WHERE Username=N'" + TxtUsername.Text + "' AND Password=N'" + TxtPassword.Text + "'"
        Dim sqlconnection As New SqlClient.SqlConnection("Data Source=.;Initial Catalog=Akhbar;Integrated Security=True")
        Dim sqlCmd As New SqlClient.SqlCommand(sql, sqlconnection)
        Dim SqlDr As SqlClient.SqlDataReader
        sqlconnection.Open()
        SqlDr = sqlCmd.ExecuteReader()
        If SqlDr.Read Then
            Session.Add("Vouroud", "fdhgdfjjgfd")
            Response.Redirect("http://localhost:2073/admin/admin.aspx")
        End If
        sqlconnection.Close()
    End Sub
End Class
