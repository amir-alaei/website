﻿Imports System
Imports System.Data

Partial Class admin_MasterPage
    Inherits System.Web.UI.MasterPage
    Protected Sub Unnamed1_Click(sender As Object, e As EventArgs)
        System.Web.Security.FormsAuthentication.SignOut()
        Session.Clear()
        Session.Abandon()
        Response.Redirect("http://localhost:2073/admin/login/Login.aspx")

    End Sub

End Class

